This library provides a convenient interface to the TB6612 motor controller.
Refer to the TB6612_hookup_guide.md (Markdown) file in the documentation
folder for more details.

Gerald Recktenwald,  gerry@pdx.edu,  2016-11-13
